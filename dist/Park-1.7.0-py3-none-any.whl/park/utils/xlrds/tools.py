import os.path

import xlrd
import xlwt
import openpyxl
from typing import Any, Union, List, Tuple
from collections.abc import Iterable
from ...conf.os import mkdir


def open_excel(path: str) -> xlrd.book.Book:
    """
    打开一个excel文件
    :param path: excel文件路径
    :return: 一个工作簿
    """
    workbook = xlrd.open_workbook(r"%s" % path)
    return workbook


def list_sheet(workbook: xlrd.book.Book) -> list:
    """
    获取excel中的sheet表列表
    :param workbook: 工作簿
    :return: 一个列表sheet名
    """
    assert isinstance(workbook, xlrd.book.Book), "必须传入xlrd读取的工作薄"
    return workbook.sheet_names()


def sheets(workbook: xlrd.book.Book) -> Any:
    """

    :param workbook:
    :return:
    """
    assert isinstance(workbook, xlrd.book.Book), "必须传入xlrd读取的工作薄"
    return workbook.sheets()


def choice_sheet(workbook: xlrd.book.Book,
                 index: Union[str, int, List[int], Tuple[int]]) -> \
        Union[xlrd.sheet.Sheet, map]:
    assert isinstance(workbook, xlrd.book.Book), "必须传入xlrd读取的工作薄"
    if isinstance(index, int):
        return workbook.sheet_by_index(index)
    elif isinstance(index, str):
        return workbook.sheet_by_name(index)
    elif isinstance(index, Iterable) and index:
        return map(lambda x: workbook.sheet_by_index(x) if isinstance(x, int) else workbook.sheet_by_name(x),
                   index)
    else:
        raise ValueError("不支持此数据类型")


def get_rows_cols(table: xlrd.sheet.Sheet) -> Tuple[Any, Any]:
    rows = table.nrows
    cols = table.ncols
    return rows, cols


def get_row_values(table: xlrd.sheet.Sheet, row: int) -> List[str]:
    if isinstance(row, int):
        return table.row_values(row)
    elif isinstance(row, slice):
        return table.row_slice(row)
    else:
        raise ValueError("传入数据错误")


def get_cell_value(table: xlrd.sheet.Sheet, row: int, column: int) -> str:
    return table.cell(row, column).value


def create_workbook():
    return xlwt.Workbook()


def add_sheet(workbook: xlwt.Workbook, name: str) -> xlwt.Worksheet:
    if name.__len__() > 31:
        name = name[:31]
    return workbook.add_sheet(r"%s" % name, cell_overwrite_ok=True)


def write_sheet(table: xlwt.Worksheet, row: int, column: int, info: str) -> Any:
    return table.write(row, column, info)


def save_excel(workbook: xlwt.Workbook, path: str) -> None:
    dirname = os.path.dirname(path)
    mkdir(dirname)
    f = open(path, 'w')
    f.close()
    workbook.save(path)


def open_a_excel(path: str, *args, **kwargs):
    return openpyxl.open(path, *args, **kwargs)
