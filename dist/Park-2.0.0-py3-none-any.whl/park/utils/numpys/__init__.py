"""
提供一些numpy方法， 大多与numpy使用方法一致
Ndarray 属于numpy类型，用于判断其是否属于numpy类型, 与 numpy.ndarray一致
"""