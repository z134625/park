import csv


if __name__ == '__main__':
    print(csv.__doc__)
